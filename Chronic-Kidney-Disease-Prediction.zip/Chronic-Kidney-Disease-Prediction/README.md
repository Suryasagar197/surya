# Chronic Kidney Disease Prediction

The dataset contains various parameters like age, blood pressure, specific gravity, albumin, sugar, red blood cells, pus cell, pus cell clumps, bacteria, blood glucose random, blood urea, serum creatinine, sodium, potassium, hemoglobin, packed cell volume, white blood cell count, red blood cell count, hypertension, diabetes mellitus, coronary artery disease, appetite, pedal edema, anemia, and class.

### 3 Models are there:
Logistic Regression, Random forest, Support vector Machine(classification), Voting combination of Logistic Regression and Random forest.


### Step to run project, open terminal of project :
```
virtualenv venv
```


```
venv\scripts\activate
```

```
pip install -r requirements.txt
```

```
streamlit run app.py
```