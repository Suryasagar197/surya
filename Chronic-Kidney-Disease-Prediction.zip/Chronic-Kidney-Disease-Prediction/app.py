import streamlit as st
import pandas as pd
import joblib
import warnings

# Suppress specific sklearn warnings
warnings.filterwarnings("ignore")

# Function to load the selected model
def load_model(model_name):
    try:
        return joblib.load(model_name)
    except FileNotFoundError:
        st.error(f"Model file '{model_name}' not found. Please ensure it exists in the directory.")
        return None

# Function to load the selected scaler
def load_scaler(scaler_name):
    try:
        return joblib.load(scaler_name)
    except FileNotFoundError:
        st.error(f"Scaler file '{scaler_name}' not found. Please ensure it exists in the directory.")
        return None

# Function to preprocess user inputs into a DataFrame
def create_input_df(user_inputs, category_map, exclude_columns):
    # Map categorical values to numerical values using the category map
    for feature, mapping in category_map.items():
        if feature in user_inputs:
            user_inputs[feature] = mapping.get(user_inputs[feature], -1)  # Default to -1 for unknown categories
    
    # Create DataFrame and drop excluded columns
    input_df = pd.DataFrame([user_inputs])
    return input_df.drop(columns=exclude_columns, errors='ignore')

# Define the mapping for categorical inputs
category_map = {
    "rbc": {"normal": 1, "abnormal": 0},
    "pc": {"normal": 1, "abnormal": 0},
    "pcc": {"present": 1, "notpresent": 0},
    "ba": {"present": 1, "notpresent": 0},
    "htn": {"yes": 1, "no": 0},
    "dm": {"yes": 1, "no": 0},
    "cad": {"yes": 1, "no": 0},
    "appet": {"good": 1, "poor": 0},
    "pe": {"yes": 1, "no": 0},
    "ane": {"yes": 1, "no": 0},
}

# Columns to exclude from the DataFrame passed to the model
exclude_columns = ['pcc', 'ba', 'cad', 'ane', 'pot', 'pe']

# Dropdown to select the model
st.title("Chronic Kidney Disease Prediction")
model_choice = st.selectbox(
    "Choose a Model for Prediction:",
    [
        "Logistic Regression",
        "Random Forest",
        "Support Vector Classifier",
        "Majority Voting (LR + RF)"
    ]
)

# Map model choice to filenames
model_mapping = {
    "Logistic Regression": "lr_classifier.pkl",
    "Random Forest": "rf_classifier.pkl",
    "Support Vector Classifier": "svc_classifier.pkl",
    "Majority Voting (LR + RF)": "majority_voting_lr_rf.pkl",
}

scaler_mapping = {
    "Logistic Regression": "scaler_lr.pkl",
    "Random Forest": "scaler_rf.pkl",
    "Support Vector Classifier": "scaler_svc.pkl",
    "Majority Voting (LR + RF)": "scaler_lr_rf.pkl",
}

# Load the selected model and scaler
model_name = model_mapping[model_choice]
scaler_name = scaler_mapping[model_choice]
loaded_model = load_model(model_name)
loaded_scaler = load_scaler(scaler_name)

# Collect categorical inputs from the user
st.subheader("Input Patient Information")
red_blood_cells = st.radio('Red Blood Cells', ('normal', 'abnormal'))
pus_cell = st.radio('Pus Cell', ('normal', 'abnormal'))
pus_cell_clumps = st.radio('Pus Cell Clumps', ('notpresent', 'present'))
bacteria = st.radio('Bacteria', ('notpresent', 'present'))
hypertension = st.radio('Hypertension', ('no', 'yes'))
diabetes_mellitus = st.radio('Diabetes Mellitus', ('no', 'yes'))
coronary_artery_disease = st.radio('Coronary Artery Disease', ('no', 'yes'))
appetite = st.radio('Appetite', ('poor', 'good'))
pedal_edema = st.radio('Pedal Edema', ('no', 'yes'))
anemia = st.radio('Anemia', ('no', 'yes'))

# Collect numerical inputs using input fields
age = st.number_input('Age (0-100)', min_value=0, max_value=100, value=58)
blood_pressure = st.number_input('Blood Pressure (0-180)', min_value=0, max_value=180, value=80)
specific_gravity = st.number_input('Specific Gravity (0.0-2.0)', min_value=0.0, max_value=2.0, value=1.02, step=0.001)
albumin = st.number_input('Albumin (0-5)', min_value=0, max_value=5, value=0)
sugar = st.number_input('Sugar (0-5)', min_value=0, max_value=5, value=0)
blood_glucose_random = st.number_input('Blood Glucose Random (0-500)', min_value=0, max_value=500, value=100)
blood_urea = st.number_input('Blood Urea (0-200)', min_value=0, max_value=200, value=50)
serum_creatinine = st.number_input('Serum Creatinine (0.0-10.0)', min_value=0.0, max_value=10.0, value=1.2, step=0.1)
sodium = st.number_input('Sodium (0-200)', min_value=0, max_value=200, value=140)
potassium = st.number_input('Potassium (0-10)', min_value=0.0, max_value=10.0, value=3.5,step=0.1)
hemoglobin = st.number_input('Hemoglobin (0-20)', min_value=0.0, max_value=20.0, value=14.0, step=0.1)
packed_cell_volume = st.number_input('Packed Cell Volume (0-100)', min_value=0, max_value=100, value=50)
white_blood_cell_count = st.number_input('White Blood Cell Count (0-20000)', min_value=0, max_value=20000, value=6700)
red_blood_cell_count = st.number_input('Red Blood Cell Count (0-10)', min_value=0.0, max_value=10.0, value=6.5, step=0.1)

# Prepare user inputs for prediction
user_inputs = {
    'age': age,
    'bp': blood_pressure,
    'sg': specific_gravity,
    'al': albumin,
    'su': sugar,
    'rbc': red_blood_cells,
    'pc': pus_cell,
    'pcc': pus_cell_clumps,
    'ba': bacteria,
    'bgr': blood_glucose_random,
    'bu': blood_urea,
    'sc': serum_creatinine,
    'sod': sodium,
    'pot': potassium,
    'hemo': hemoglobin,
    'pcv': packed_cell_volume,
    'wbcc': white_blood_cell_count,
    'rbcc': red_blood_cell_count,
    'htn': hypertension,
    'dm': diabetes_mellitus,
    'cad': coronary_artery_disease,
    'appet': appetite,
    'pe': pedal_edema,
    'ane': anemia,
}

# Prediction button
if st.button('Submit'):
    if not loaded_model:
        st.error("Model could not be loaded. Please check the model file.")
    elif not loaded_scaler:
        st.error("Scaler could not be loaded. Please check the scaler file.")
    else:
        # Create a DataFrame without the excluded columns
        input_df = create_input_df(user_inputs, category_map, exclude_columns)
        
        # Scale the input data
        input_scaled = loaded_scaler.transform(input_df)
        
        # Make predictions
        prediction = loaded_model.predict(input_scaled)
        
        # Display the result
        result = "Chronic Kidney Disease is likely." if prediction[0] == 1 else "No Chronic Kidney Disease."
        st.success(f"Prediction: {result}")
